# Muhtawa — round 3 improvements

Picks up the remaining items from the first code review that weren't blocked
on the LCGPA Excel template. Scoring layer is unchanged from the V2 update
and still matches Excel bit-exactly.

## What changed

### Backend

**`api/chat.js`**
- Model upgraded: `claude-sonnet-4-20250514` → **`claude-sonnet-4-6`**. The
  old model is on Anthropic's deprecation list with retirement scheduled for
  June 15, 2026. Sonnet 4.6 is the recommended migration target — same
  pricing tier, better quality, supports the 1M-token context window.
- Request-size cap raised from 50KB to 100KB so the growing regulations
  database has room to breathe in the system prompt.

**`api/regulations.js`**
- Server-side content cap added: 500,000 chars per regulation (plus shorter
  caps on title and summary). Guards against accidental paste-bombs and
  keeps individual regulation payloads manageable.

### Frontend — auth improvements

**Password reset flow.** A "Forgot password?" link now appears next to the
Password label on the sign-in screen. Clicking it takes users to an email
form; submitting calls `supabase.auth.resetPasswordForEmail` and shows a
"Check your email" confirmation. When the user clicks the link in the
reset email, they land back on the app, Supabase fires a `PASSWORD_RECOVERY`
auth event, and we route them to a dedicated "Set a new password" screen.

**Email verification.** If Supabase's email-confirmation setting is on,
signup now returns a user without a session. Previously the app tried to
drop the user straight onto the dashboard — which silently failed. Now we
detect this and show a "Check your email to verify your account" screen
instead. Likely a real contributor to your activation funnel drop-off
(users sign up, don't verify, never come back).

### Frontend — assessment management

**Assessment naming.** Each assessment now has an optional `name` field.
A prominent input appears at the top of the Calculator ("Name this
assessment, e.g., 'FY 2024 Baseline'"). Names show on the dashboard list
instead of just dates; if no name is provided, the date is used as fallback
(so existing assessments keep working without changes).

**Assessment delete.** A small `✕` button next to each assessment on the
dashboard. Confirms before deleting, removes from Supabase (`delete().eq('id', ...)`)
and from local state. Uses browser `confirm()` for now — styled modal is
deferred.

### Frontend — auto-save

The old effect fired a Supabase write every 1.5 seconds on *every* keystroke
and also on every component re-render. Now it:
- Debounces to **3 seconds**
- **Only fires when the assessment actually changed** (compared against a
  JSON snapshot of the last saved state)
- Shows a small "Saving… / Saved" pill in the header

Net effect: roughly a 5-10x reduction in writes during normal editing.

### Misc

- Dashboard "Sectors" card now pulls the count dynamically from
  `SECTORS.length` (showed stale "39" in V2, now correctly "38").
- Small layout tweak to dashboard assessment rows so long names truncate
  cleanly with ellipsis.

## Deploy

From Git Bash in your `muhtawa-project` repo root:

```bash
tar -xzf muhtawa-v3-improvements.tar.gz
git status
git add -A
git commit -m "Model upgrade + password reset + email verification + assessment naming/delete + auto-save improvements"
git push
```

No environment variable or DB migration required — this builds on your
existing Supabase tables.

## Configure Supabase email templates (optional polish)

Supabase sends both the verification email and the password-reset email by
default, but the templates look very generic. If you want them branded, go
to **Supabase → Authentication → Email Templates** and customize the
"Confirm signup" and "Reset password" templates. The `{{ .ConfirmationURL }}`
and `{{ .RedirectTo }}` tokens already work — just change the copy.

Also check **Authentication → URL Configuration → Site URL** is set to
your production domain (e.g. `https://muhtawa.talalalzayed.com`). The
redirect URL for password reset defaults to `window.location.origin`, which
works, but Supabase requires the origin to be allow-listed under
**Authentication → URL Configuration → Redirect URLs**.

## Smoke tests after deploy

1. **Model upgrade.** Open the AI Advisor and ask a question. Response
   quality should feel at least as good as before; there's no user-visible
   indicator of the model change.
2. **Forgot password.** On sign-in, click "Forgot password?". Enter your
   email, confirm you see the "Check your email" screen, then check your
   inbox for the reset link. Click it, you should land on the "Set a new
   password" screen. Set a new password, then sign in with it.
3. **Email verification.** Sign up with a fresh email. You should see the
   "Check your email" screen instead of the dashboard. Check the inbox,
   click the verification link, then sign in normally.
4. **Assessment naming.** Create a new assessment, type a name at the top.
   Go back to the dashboard — the name shows instead of the date.
5. **Assessment delete.** Click the `✕` next to an assessment on the
   dashboard. Confirm in the browser dialog. Assessment disappears from
   the list. Refresh — it should stay gone (deleted from Supabase).
6. **Auto-save.** Start editing an assessment. Header should say
   "Saving…" briefly, then "Saved", then fade back to "Auto-saves".
   Check Supabase to confirm you're not seeing a write on every keystroke.
7. **Regulations content cap.** Try pasting a 600KB+ blob into a new
   regulation's Content field and save. Should reject with a friendly
   error.

## Still not done (deferred)

- **Made in Saudi DB persistence.** The form currently lives only in
  browser state. Making it save/load/list/delete is a full feature — new
  Supabase table, CRUD operations, dashboard integration — and deserves
  its own session.
- **Styled delete modal.** `confirm()` is functional; a prettier modal is
  pure polish.

## What's not changed

- Scoring layer (sectors.js, scoring.js) — unchanged from the V2 update,
  still bit-exact against the official LCGPA Excel.
- Security fixes from the first update — auth on `/api/chat`, per-user
  rate limiting, restricted CORS, admin-only writes on `/api/regulations`
  — all still in place.
